package eu.kanade.tachiyomi.extension.en.mangakakalotgg

import eu.kanade.tachiyomi.multisrc.madara.Madara

class MangakakalotGG : Madara(
    "Mangakakalot.gg",
    "https://mangakakalot.gg",
    "en"
)